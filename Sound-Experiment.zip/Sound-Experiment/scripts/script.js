
var mic; 

function setup(){
	mic = new p5.AudioIn();
	$("body").click(function(){
		mic.start();
		console.log('start');
	});
}


function draw(){

	//var vol = mic.getLevel();
	//console.log(vol);

	//var vol = mic.getLevel();
	//console.log(vol);
	//updateSize(mic.getLevel());

	/*
	function updateSize(volume){
		console.log(volume);
	}
	*/

}










	//var text = document.getElementById("text");


	/*
	var myScale = d3.scaleLinear()
	  .domain([0, 100])
	  .range([100, 599]);

	  var letterSpace = d3.scaleLinear()
	  .domain([0, 100])
	  .range([-25, 25]);


	function getMousePos(canvas, evt) {
	    var rect = canvas.getBoundingClientRect();
	    var x = evt.clientX - rect.top;
	    var y = evt.clientY - rect.top;
	    resize(Math.round((y/rect.bottom)*100), Math.round((x/rect.bottom)*100) )
	}

	document.getElementById("mouse-canvas").onmousemove = function(event) {getMousePos(this, event)};


	function resize(inputY, inputX){
		var scaleAmount = myScale(inputY);
		var letterSpacing = letterSpace(inputX);
		var variationSettings = {"font-variation-settings": "'wght' " + scaleAmount};
		$(text).css('font-weight', scaleAmount);
		$(text).css(variationSettings);
		$(text).css('letter-spacing', letterSpacing+'px');
		$(text2).css('font-weight', scaleAmount);
		$(text2).css(variationSettings);
		$(text2).css('letter-spacing', letterSpacing+'px');
	}


	*/







