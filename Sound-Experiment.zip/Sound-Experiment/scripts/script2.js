var mic
var vol = 0;

var myScale = d3.scaleLinear()
	  .domain([0, 1])
	  .range([201, 699]);

function setup() {
  // Create an Audio input
  mic = new p5.AudioIn();
  // start the Audio Input.
  // By default, it does not .connect() (to the computer speakers)
  mic.start();
}

function draw() {
  // Get the overall volume (between 0 and 1.0)
   var vol = mic.getLevel();
   updateSize(vol);
}

function updateSize(volume){
	var fontWeight = myScale(volume);
	console.log(fontWeight);
	var variationSettings = {"font-variation-settings": "'wght' " + fontWeight};
	$("#text").css('font-weight', fontWeight);
	$("#text").css(variationSettings);
}


// Click to allow sound input from user
function touchStarted() {
  getAudioContext().resume()
}