const bodyParser = require('body-parser');
const urlencodedParser = bodyParser.urlencoded({extended: false});
const cheerio = require('cheerio');
const puppeteer = require('puppeteer');


module.exports = function(app){

	app.get('/index', function(req, res){
		res.render('index');
	});

	app.post('/index', urlencodedParser, function(req, res){
		// Adds new item to the array
		// Get data from the view and add to noSQL database

		// Finds and retrieves HTML from input website URL
		function getDocument(websiteURL){

			console.log(websiteURL);
			(async () => {
			  const browser = await puppeteer.launch();
			  const page = await browser.newPage();

			  await page.goto(websiteURL);

			  let bodyHTML = await page.evaluate(() => document.body.innerHTML);

			  var results = processBody(bodyHTML);
			  console.log('results: ' + results);
			  browser.close();

			  //return results;
			  //res.render('results', {results});
			  res.json({results});
			})();
		}

		getDocument(req.body.item);

		//res.render('index', {todos: data});
	});
};



// Body of html is processed, returns the accessibility metrics
function processBody(html){
	const $ = cheerio.load(html);
	const images = $('img');
	var store = [];

	// Grab headers used on the site 
	const h1 = $('h1');
	const h2 = $('h2');
	const h3 = $('h3');
	const h4 = $('h4');
	const h5 = $('h5');

	// Place the headers all in an array 
	var headers = ["H1: "+ h1.length,"H2: "+ h2.length,"H3: "+ h3.length,"H4: "+ h4.length,"H5: "+ h5.length];

	// Count how many alt tags are used, out of the total number of images 
	var totalAlts = 0;
	var alts = [];
	for(var i = 0; i < images.length; i ++){
		if(images[i].attribs.alt){
			totalAlts ++;
			//alts.push(images[i].attribs.alt);
			var entry = {"alt": images[i].attribs.alt, "src": images[i].attribs.src};
			alts.push(entry);
		}
	}

	//store.push(alts);

	store.push(images.length);
	store.push(totalAlts);
	store.push(images.length-totalAlts);
	store.push(alts);

	/*
	console.log(images.length + " Images total");
	console.log((totalAlts/images.length)*100 + "% Of images have alt tags");
	console.log('ALTS:');
	console.log(alts);
	console.log('Headers present:');
	console.log(headers);
	*/
	//return store;
	//console.log(store);
	return store;
}


// Updates the document content 
function updatePage(){

}




