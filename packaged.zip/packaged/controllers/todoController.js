var bodyParser = require('body-parser');
var mongoose = require('mongoose');


// Connect to the server
/*
mongoose.connect('mongodb+srv://test:SLbBGeaydCTAec35@cluster0-3csdr.mongodb.net/test?retryWrites=true&w=majority', {
useUnifiedTopology: true,
useNewUrlParser: true
}).then(() => console.log('connected')).catch(err => {console.log(err) });
*/

// Create Schema, like a blueprint for our data
/*
var todoSchema = new mongoose.Schema({
	item: String
});
*/

// Create To Do Model. Model will be stored as a collection on MongoDB
var Todo = mongoose.model('Todo', todoSchema);


var urlencodedParser = bodyParser.urlencoded({extended: false});


module.exports = function(app){

	/*
	app.get('/index', function(req, res){
		// Get data from noSQL database and pass it to the view

		Todo.find({}, function(err, data){
			if(err){
				throw err;
			}
			res.render('index', {todos: data});
		});
	});
	*/

	app.post('/index', urlencodedParser, function(req, res){
		// Adds new item to the array
		// Get data from the view and add to noSQL database

		var newTodo = Todo(req.body).save(function(err, data){
			if(err){
				throw err;
			}
			res.json(data);
		});
	});

	app.delete('/index/:item', function(req, res){
		// Delete requested item from noSQL server

		Todo.find({item: req.params.item.replace(/\-/g, " ")}).deleteOne(function(err, data){
			if(err){
				throw err;
			}
			res.json(data);
		});
	});


};