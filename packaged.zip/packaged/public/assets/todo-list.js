$(document).ready(function(){

	var name = document.getElementById('name');
	var s1 = document.getElementById('s1');
	var s2 = document.getElementById('s2');
	var s3 = document.getElementById('s3');
	var parent = document.getElementById('image-gallery');

	// Controls AJAX requests
	$('form').on('submit', function(){
		event.preventDefault();
		// Takes form input and puts it in data format
		var item = $('form input');
		var website = {item: item.val()};

		// Sends post data to the handler in the "todoController" file
		$.ajax({
			type: 'POST',
			url: '/index',
			data: website,
			success: function(data){
				// Do something with the data via front-end framework
				console.log(data);
				name.innerHTML = website.item;
				s1.innerHTML = "Images found: " + data.results[0];
				s2.innerHTML = "Have alt tags: " + data.results[1];
				s3.innerHTML = "Missing alt tags: " + data.results[2];

				// Add elements to the DOM
				for(var i = 0; i < data.results[3].length; i++){
					console.log(data.results[3][i]);
					var imageCon = document.createElement("div");
					imageCon.className = "image-container";

					var img = document.createElement("div"); 
					img.className = "image"; 
					img.style.backgroundImage = "url("+data.results[3][i].src+")";

					var altText = document.createElement("h5");
					var newContent = document.createTextNode(data.results[3][i].alt);
					altText.className = "alt-text"; 
					altText.appendChild(newContent);  

					// Add elements to parent
					imageCon.appendChild(img);
					imageCon.appendChild(altText);

					parent.appendChild(imageCon);
				}
			}
		});
	});

});