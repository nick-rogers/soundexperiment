// Requirements imported 
// express for the GET and POST requests 
// todoController controls the flow of data to the user 
var express = require('express');
var altHandler = require('./controllers/altHandler');

// Initialize the express app 
var app = express();

// Set up template engine 
app.set('view engine', 'ejs');

// Static files accessed
app.use(express.static('./public'));

// Fire controllers
// App variable is passed into the other js file for editing 
altHandler(app);




// Listen to port 

app.listen(3000);
console.log('You are listening to port 3000');












